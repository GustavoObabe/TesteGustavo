<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>TesteGustavo</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            <h1>Teste Gustavo</h1>
            <hr />        
        <form action="/enviar" method="POST">
            <input type="hidden" name="_token" value="{{ csrf_token()}}">
            <div class="form-group">
            <label for="nomeproduto">Nome do Produto</label>
            <input type="text" id="nomeproduto" name="nomeproduto" class="form-control" placeholder="Nome do Produto">
            </div>
            <div class="form-group">
                <label for="codigoproduto"> Código do Produto</label>
                <input type="text" id="codigoproduto" name="codigoproduto" class="form-control" placeholder="Código do Produto">  
            </div>
            <div class="form-group">
                <label for="categoria"> Categoria</label>
                <input type="text" id="categoria" name="categoria" class="form-control" placeholder="Categoria">  
            </div>
            <div class="form-group">
                <label for="precounitario"> Preço Unitário</label>
                <input type="text" id="precounitario" name="precounitario" class="form-control" placeholder="Preço unitário">  
            </div>
            <div class="form-group">
                <label for="descricao"> Descrição</label>
                <textarea name="descricao" id="descricao" class="form-control" placeholder="Digite sua descriçao" cols="30" rows="10"></textarea>            </div>
    
            <button type="submit" class="btn btn-default">Enviar</button>
        </form>
        </div>
    </body>
</html>