<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
});

Route::post('/enviar', function (Illuminate\Http\Request $request) {

    $produtos = new App\Models\Produto();
    $produtos->codigoproduto = $request->get('codigoproduto');
    $produtos->nomeproduto = $request->get('nomeproduto');
    $produtos->categoria =$request->get('categoria');
    $produtos->precounitario = $request->get('precounitario');
    $produtos->descricao = $request->get('descricao');

    $produtos->save();

    echo "Sua mensagem foi armazenada com sucesso! Código: " . $produtos->id;
});
    
Route::get('/lista', function() {
    return view ('lista', array('produtos' => App\Models\Produto::all()));
});
